# CS--4350--The-Adjudicators

Project title: Judging App  
Group name: The Adjudicators  
Team members: Charles Murry, Aiba Diane, Ayomide Onafowokan, Edith Sanchez, Samual Holison  
